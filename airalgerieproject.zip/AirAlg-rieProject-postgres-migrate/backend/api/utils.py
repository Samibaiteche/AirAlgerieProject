from rest_framework_simplejwt.tokens import RefreshToken
from rest_framework_simplejwt.tokens import AccessToken
from django.contrib.auth import get_user_model
from django.db import connection
from .models import Admin

def get_tokens_for_user(user):
    refresh = RefreshToken.for_user(user)

    return {
        'refresh': str(refresh),
        'access': str(refresh.access_token),
    }

def extract_token_from_request(request):
    auth_header = request.headers.get('Authorization', None)
    if auth_header is not None:
        # Split the header to get the token
        prefix, token = auth_header.split(' ')
        if prefix.lower() == 'Bearer'.lower():
            return token
    return None

def get_admin_user_from_token(token):
    access_token = AccessToken(token)
    user_id = access_token['user_id']
    
    User = get_user_model()
    
    user = User.objects.get(id=user_id)
    
    admin = Admin.objects.get(admin=user)
    
    return admin


def sql_query(query, params=None):
    with connection.cursor() as cursor:
        cursor.execute(query, params)  # Execute the query
        return cursor.fetchall()  # Get the result (if any)