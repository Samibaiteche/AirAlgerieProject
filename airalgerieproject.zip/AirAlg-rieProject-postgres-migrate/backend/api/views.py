from rest_framework.decorators import api_view, permission_classes, authentication_classes
from django.contrib.auth import authenticate
from rest_framework.response import Response
from rest_framework.permissions import IsAuthenticated
from rest_framework_simplejwt.authentication import JWTAuthentication
from django.db.models import Sum, Count
from django.db.models.functions import TruncMonth
from django.utils import timezone
from datetime import timedelta,datetime
from .utils import *
from .models import *

@api_view(['GET'])
@authentication_classes([JWTAuthentication])
@permission_classes([IsAuthenticated])
def index(request):
    user = get_admin_user_from_token(extract_token_from_request(request))

    print(user)
    
    return Response("OK")

@api_view(['POST'])
def login_view(request):
    username = request.data.get("username")
    password = request.data.get("password")
    if ( username and password ):
        user = authenticate(request,username=username, password=password)
        if (user is not None):
            return Response(get_tokens_for_user(user))


        return Response({"message":"Wrong Credentials"}, status=401)

    return Response({"message":"Missing Fields"}, status=400)

@api_view(['GET'])
@authentication_classes([JWTAuthentication])
@permission_classes([IsAuthenticated])
def get_profile(request):
    admin = get_admin_user_from_token(extract_token_from_request(request))
    
    return Response(
        {
            "id": admin.id,
            "username": admin.admin.username,
            "id_direction": admin.admin_dir
        }
    )

@api_view(['GET'])
@authentication_classes([JWTAuthentication])
@permission_classes([IsAuthenticated])
def get_direction(request):
    admin = get_admin_user_from_token(extract_token_from_request(request))
    
    direction = Direction.objects.get(id=admin.admin_dir)
    
    return Response(
        {
            "id": direction.id,
            "name": direction.direction_name,
            "id_division": direction.id_division.id
        }
    )

@api_view(['GET'])
@authentication_classes([JWTAuthentication])
@permission_classes([IsAuthenticated])
def get_directions(request):
    
    directions = [ (d.id, d.direction_name) for d in Direction.objects.all() ]
        
    return Response({
        "directions":directions
    })

@api_view(['GET'])
@authentication_classes([JWTAuthentication])
@permission_classes([IsAuthenticated])
def get_employees(request):
    admin = get_admin_user_from_token(extract_token_from_request(request))
    direction = Direction.objects.get(id=admin.admin_dir)
    
    loop_in = []
    employees = []

    if (direction.direction_name in ['Direction Générale','Ressources Humaines']):
        loop_in = Employee.objects.all()
    else:
        loop_in = Employee.objects.filter(id_direction=direction)
    
    for e in loop_in :
        obj = {
            "id": e.id,
            "name": e.employee_name,
            "gender": e.employee_gender,
            "category": e.employee_category,
            "gross_salary": e.employee_gross_salary,
            "employer_contributions": e.employee_employer_contributions,
            "social_contributions": e.employee_social_contributions,
            "id_direction": e.id_direction.id
        }
        
        employees.append(obj)
    
    
    return Response(
        {
            "employees": employees
        }
    )

@api_view(['GET'])
@authentication_classes([JWTAuthentication])
@permission_classes([IsAuthenticated])
def get_num_employees(request):
    admin = get_admin_user_from_token(extract_token_from_request(request))
    
    num = Employee.objects.filter(id_direction=admin.admin_dir).count()
    
    return Response({
        "num":num
    })

@api_view(['GET'])
@authentication_classes([JWTAuthentication])
@permission_classes([IsAuthenticated])
def get_chart_data(request):
    
    admin = get_admin_user_from_token(extract_token_from_request(request))
    
    print(admin)
    
    twelve_months_ago = timezone.now().date() - timedelta(days=365)
    
    if (admin.admin_role):
        result = (
            Pay.objects.filter(pay_date__gte=twelve_months_ago) 
            .annotate(month=TruncMonth('pay_date'))
            .values('month')
            .annotate(
                sum_gross_salary_archive=Sum('gross_salary_archive'),
                sum_employer_contributions_archive=Sum('employer_contributions_archive'),
                sum_social_contributions_archive=Sum('social_contributions_archive')
            )
            .order_by('month')
        )
    
    else:
        result = (
            Pay.objects.filter(
                id_emp__id_direction_id=admin.admin_dir,
                pay_date__gte=twelve_months_ago  
            )
            .annotate(month=TruncMonth('pay_date'))
            .values('month') 
            .annotate(
                sum_gross_salary_archive=Sum('gross_salary_archive'),
                sum_employer_contributions_archive=Sum('employer_contributions_archive'),
                sum_social_contributions_archive=Sum('social_contributions_archive')
            ) 
            .order_by('month')
        )
        
        print(result.query)
        
    return Response({
        "chart_data":result
    })


@api_view(['POST'])
@authentication_classes([JWTAuthentication])
@permission_classes([IsAuthenticated])
def filter_chart_data(request):

    starting_month = request.data.get("starting_month")
    ending_month = request.data.get("ending_month")
    starting_year = request.data.get("starting_year")
    ending_year = request.data.get("ending_year")
    gender = request.data.get("gender")
    category = request.data.get("category")
    direction = request.data.get("direction")
     
    query = Pay.objects.all()

    # Apply date filters (if provided)
    if starting_month and starting_year:
        start_date = datetime(starting_year, starting_month, 1)
        start_date=(timezone.make_aware(start_date))
        query = query.filter(pay_date__gte=start_date)

    if ending_month and ending_year:
        # Get the last day of the ending month
        end_date = datetime(ending_year, ending_month, 1).replace(day=28) + timedelta(days=4)
        end_date = end_date - timedelta(days=end_date.day)
        end_date = timezone.make_aware(end_date)
        query = query.filter(pay_date__lte=end_date)

    # Apply employee-related filters
    if gender is not None:
        query = query.filter(id_emp__employee_gender=gender)

    if category is not None:
        query = query.filter(id_emp__employee_category=category)

    if direction is not None:
        query = query.filter(id_emp__id_direction_id=direction)

    # Annotate and aggregate the data by month
    result = (
        query
        .annotate(month=TruncMonth('pay_date'))  # Group by month
        .values('month')
        .annotate(
            sum_gross_salary_archive=Sum('gross_salary_archive'),
            sum_employer_contributions_archive=Sum('employer_contributions_archive'),
            sum_social_contributions_archive=Sum('social_contributions_archive')
        )
        .order_by('month')
    )
    
    
    return Response({
        "chart_data": result
    })


@api_view(['GET'])
@authentication_classes([JWTAuthentication])
@permission_classes([IsAuthenticated])
def get_admin_info(request):
    admin = get_admin_user_from_token(extract_token_from_request(request))
    
    return Response({
        "id": admin.id,
        "username":admin.admin.username
    })