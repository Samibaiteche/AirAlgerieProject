from django.contrib import admin
from .models import *

# Register your models here.
admin.site.register(Entreprise)
admin.site.register(Division)
admin.site.register(Direction)
admin.site.register(Employee)
admin.site.register(Pay)
admin.site.register(Admin)
