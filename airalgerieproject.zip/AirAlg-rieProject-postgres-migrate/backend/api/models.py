from django.db import models
from django.contrib.auth.models import User

class Entreprise(models.Model):
    entreprise_name = models.CharField(max_length=255)
    
    def __str__(self):
        return self.entreprise_name

class Division(models.Model):
    division_name = models.CharField(max_length=512)
    id_entreprise = models.ForeignKey(Entreprise, on_delete=models.CASCADE)
    
    def __str__(self):
        return self.division_name

class Direction(models.Model):
    direction_name = models.CharField(max_length=512)
    id_division = models.ForeignKey(Division, on_delete=models.CASCADE)
    
    def __str__(self):
        return self.direction_name


class Employee(models.Model):
    employee_name = models.CharField(max_length=512)
    employee_gender = models.BooleanField()
    employee_category = models.CharField(max_length=255)
    employee_gross_salary = models.FloatField()
    employee_employer_contributions = models.FloatField()
    employee_social_contributions = models.FloatField()
    id_direction = models.ForeignKey(Direction, on_delete=models.CASCADE)
    
    def __str__(self):
        return self.employee_name

class Pay(models.Model):
    id_emp = models.ForeignKey(Employee,on_delete=models.DO_NOTHING)
    pay_date = models.DateTimeField()
    gross_salary_archive = models.FloatField()
    employer_contributions_archive = models.FloatField()
    social_contributions_archive = models.FloatField()
    
    class Meta:
        constraints = [
            models.UniqueConstraint(fields=['id_emp', 'pay_date'], name='unique_id_date')
        ]


class Admin(models.Model):
    admin = models.OneToOneField(User, on_delete=models.CASCADE)
    admin_role = models.BooleanField()
    admin_dir = models.IntegerField()
    
    def __str__(self):
        return self.admin.username