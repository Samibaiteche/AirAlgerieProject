from django.contrib import admin
from django.urls import path
from . import views
from rest_framework_simplejwt.views import TokenObtainPairView, TokenRefreshView, TokenVerifyView

urlpatterns = [
    path("",views.index),
    path("login",views.login_view),
    path("profile",views.get_profile),
    path("direction",views.get_direction),
    path("directions",views.get_directions),
    path("employees",views.get_employees),
    path("employeesnum",views.get_num_employees),
    path("chart",views.get_chart_data),
    path("filter",views.filter_chart_data),
    path("admin",views.get_admin_info)
]
