from api.models import *
from faker import Faker
import random
from django.contrib.auth.models import User
from datetime import datetime
from django.utils import timezone
faker = Faker()

def create_all():
  
    
  en = Entreprise.objects.create(entreprise_name="Air Algérie")
  
  div = Division.objects.create(division_name = "Division A",id_entreprise=en)
  
  directions = [Direction.objects.create(direction_name="Direction Générale",id_division=div)]
  
  u = User.objects.create_user(username="dg",password="adminadminadmin")
  a = Admin.objects.create(admin=u,admin_role=True,admin_dir=directions[-1].id)
  
  directions.append(Direction.objects.create(direction_name="Ressources Humaines",id_division=div))
  u = User.objects.create_user(username="rh",password="adminadminadmin")
  a = Admin.objects.create(admin=u,admin_role=True,admin_dir=directions[-1].id)
  
  directions.append(Direction.objects.create(direction_name="Finances Et Comptabilité",id_division=div))
  u = User.objects.create_user(username="fc",password="adminadminadmin")
  a = Admin.objects.create(admin=u,admin_role=False,admin_dir=directions[-1].id)
  
  directions.append(Direction.objects.create(direction_name="Commerciale",id_division=div))
  u = User.objects.create_user(username="co",password="adminadminadmin")
  a = Admin.objects.create(admin=u,admin_role=False,admin_dir=directions[-1].id)
  
  directions.append(Direction.objects.create(direction_name="Qualité",id_division=div))
  u = User.objects.create_user(username="qu",password="adminadminadmin")
  a = Admin.objects.create(admin=u,admin_role=False,admin_dir=directions[-1].id)
  
  directions.append(Direction.objects.create(direction_name="Exploitation",id_division=div))
  u= User.objects.create_user(username="ex",password="adminadminadmin")
  a = Admin.objects.create(admin=u,admin_role=False,admin_dir=directions[-1].id)
  
  directions.append(Direction.objects.create(direction_name="Sytémes d'Informations",id_division=div))
  u= User.objects.create_user(username="si",password="adminadminadmin")
  a = Admin.objects.create(admin=u,admin_role=False,admin_dir=directions[-1].id)
  
  directions.append(Direction.objects.create(direction_name="Juridique",id_division=div))
  u= User.objects.create_user(username="ju",password="adminadminadmin")
  a = Admin.objects.create(admin=u,admin_role=False,admin_dir=directions[-1].id)
  
  directions.append(Direction.objects.create(direction_name="Hygiène et Sécurité et Médecine de Travail",id_division=div))
  u= User.objects.create_user(username="hs",password="adminadminadmin")
  a = Admin.objects.create(admin=u,admin_role=False,admin_dir=directions[-1].id)
  
  directions.append(Direction.objects.create(direction_name="Maintenance Aéronotique",id_division=div))
  u= User.objects.create_user(username="ma",password="adminadminadmin")
  a = Admin.objects.create(admin=u,admin_role=False,admin_dir=directions[-1].id)
  
  directions.append(Direction.objects.create(direction_name="Logistiques",id_division=div))
  u= User.objects.create_user(username="lo",password="adminadminadmin")
  a = Admin.objects.create(admin=u,admin_role=False,admin_dir=directions[-1].id)
  
  directions.append(Direction.objects.create(direction_name="Audits et Inspections",id_division=div))
  u= User.objects.create_user(username="au",password="adminadminadmin")
  a = Admin.objects.create(admin=u,admin_role=False,admin_dir=directions[-1].id)
  
  directions.append(Direction.objects.create(direction_name="Stratégique",id_division=div))
  u= User.objects.create_user(username="st",password="adminadminadmin")
  a = Admin.objects.create(admin=u,admin_role=False,admin_dir=directions[-1].id)
  
  directions.append(Direction.objects.create(direction_name="Relations Clients",id_division=div))
  u= User.objects.create_user(username="rc",password="adminadminadmin")
  a = Admin.objects.create(admin=u,admin_role=False,admin_dir=directions[-1].id)
  
  directions.append(Direction.objects.create(direction_name="Programmes",id_division=div))
  u= User.objects.create_user(username="prog",password="adminadminadmin")
  a = Admin.objects.create(admin=u,admin_role=False,admin_dir=directions[-1].id)
  
  directions.append(Direction.objects.create(direction_name="Engeneering",id_division=div))
  u= User.objects.create_user(username="eng",password="adminadminadmin")
  a = Admin.objects.create(admin=u,admin_role=False,admin_dir=directions[-1].id)
  
  directions.append(Direction.objects.create(direction_name="Control des Opérations",id_division=div))
  u= User.objects.create_user(username="cc",password="adminadminadmin")
  a = Admin.objects.create(admin=u,admin_role=False,admin_dir=directions[-1].id)
  
  for d in directions:
    num_employees = 0
    
    if (d.direction_name=="Direction Générale"):
      num_employees = 20
    else:
      num_employees = 100
    for _ in range(num_employees):
      gross_salary = random.randint(100,200)*1000
      Employee.objects.create(employee_name=f"{faker.last_name()}.{faker.first_name()}",employee_gender=random.choice([True,False]),employee_category=random.choice(['executant',"maitrise","cadre"]),employee_gross_salary=gross_salary,employee_employer_contributions=0.25*gross_salary,employee_social_contributions=0.02*gross_salary,id_direction=d)
      

def pay_all():
  employees = Employee.objects.all()
  
  for i in [2023,2024]:
    for m in range(1,13):
      pay_date= datetime(i,m,1)
      
      p = random.randint(5,40)
      n = int(len(employees)*p/100)
      
      emp_indexes = random.choices(range(len(employees)),k=n)
      
      for j in range(len(employees)):
        if (j in emp_indexes):
          continue

        Pay.objects.create(id_emp=employees[j],gross_salary_archive=employees[j].employee_gross_salary+random.randint(2,5)*1000,employer_contributions_archive=employees[j].employee_employer_contributions,social_contributions_archive=employees[j].employee_social_contributions,pay_date=timezone.make_aware(pay_date))


def remove_all():
  Pay.objects.all().delete()
  Employee.objects.all().delete()
  Direction.objects.all().delete()
  Division.objects.all().delete()  
  Entreprise.objects.all().delete()
  Admin.objects.all().delete()
  
  for u in User.objects.all():
    if (u.username!="admin"):
      u.delete()
  
def test():
  e = Employee.objects.first()
  Pay.objects.create(id_emp=e,gross_salary_archive=e.employee_gross_salary,employer_contributions_archive=e.employee_employer_contributions,social_contributions_archive=e.employee_social_contributions,pay_date=timezone.make_aware(datetime(2024,12,1)))

remove_all()
create_all()
pay_all()