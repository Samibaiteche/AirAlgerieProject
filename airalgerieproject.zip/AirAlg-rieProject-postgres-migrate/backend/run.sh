#!/bin/sh

./venv/bin/python manage.py makemigrations
./venv/bin/python manage.py migrate

# populate
./venv/bin/python manage.py shell < populate.py
echo "populate ended"

./venv/bin/python manage.py runserver 0.0.0.0:8000