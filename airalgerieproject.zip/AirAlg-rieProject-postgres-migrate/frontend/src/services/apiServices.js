// apiService.js
import { api, disconnect, months } from "../utils/index";

export const login = async (credentials) => {
  try {
    const response = await api.post("/api/login", credentials);
    return response.data;
  } catch (error) {
    throw error;
  }
};

export const getChartData = async () => {
  try {
    const res = await api.get("/api/chart", {
      headers: {
        Authorization: `Bearer ${localStorage.getItem("token")}`,
      },
    });
    var data = res.data.chart_data;

    var results = [];

    data.forEach((item) => {
      var date = new Date(item.month);
      results.push({
        name: months[date.getMonth() + 1],
        sb: item.sum_gross_salary_archive,
        cp: item.sum_employer_contributions_archive,
        cs: item.sum_social_contributions_archive,
        st:
          item.sum_gross_salary_archive +
          item.sum_employer_contributions_archive +
          item.sum_social_contributions_archive,
      });
    });

    return results;
  } catch (err) {
    if (err.response.status == 401) {
      disconnect();
    } else {
      throw err;
    }
  }
};

export const getEmployeesData = async () => {
  try {
    const res = await api.get("/api/employees", {
      headers: {
        Authorization: `Bearer ${localStorage.getItem("token")}`,
      },
    });

    return res.data.employees;
  } catch (err) {
    if (err.response.status == 401) {
      disconnect();
    } else {
      throw err;
    }
  }
};

export const getNumEmployees = async () => {
  try {
    const res = await api.get("/api/employeesnum", {
      headers: {
        Authorization: `Bearer ${localStorage.getItem("token")}`,
      },
    });

    return res.data.num;
  } catch (err) {
    if (err.response.status == 401) {
      disconnect();
    } else {
      throw err;
    }
  }
};

export const getDirection = async () => {
  try {
    const res = await api.get("/api/direction", {
      headers: {
        Authorization: `Bearer ${localStorage.getItem("token")}`,
      },
    });

    return res.data;
  } catch (err) {
    if (err.response.status == 401) {
      disconnect();
    } else {
      throw err;
    }
  }
};

export const getDirections = async () => {
  try {
    const res = await api.get("/api/directions", {
      headers: {
        Authorization: `Bearer ${localStorage.getItem("token")}`,
      },
    });

    return res.data.directions;
  } catch (err) {
    if (err.response.status == 401) {
      disconnect();
    } else {
      throw err;
    }
  }
};

export const getAdmin = async () => {
  try {
    const res = await api.get("/api/admin", {
      headers: {
        Authorization: `Bearer ${localStorage.getItem("token")}`,
      },
    });

    return res.data;
  } catch (err) {
    if (err.response.status == 401) {
      disconnect();
    } else {
      throw err;
    }
  }
};

export const filterChart = async (data) => {
  try {
    const res = await api.post("/api/filter", data, {
      headers: {
        Authorization: `Bearer ${localStorage.getItem("token")}`,
      },
    });
    var data = res.data.chart_data;

    var results = [];

    data.forEach((item) => {
      var date = new Date(item.month);
      results.push({
        name: months[date.getMonth() + 1],
        sb: item.sum_gross_salary_archive,
        cp: item.sum_employer_contributions_archive,
        cs: item.sum_social_contributions_archive,
        st:
          item.sum_gross_salary_archive +
          item.sum_employer_contributions_archive +
          item.sum_social_contributions_archive,
      });
    });

    return results;
  } catch (err) {
    if (err.response.status == 401) {
      disconnect();
    } else {
      throw err;
    }
  }
};
