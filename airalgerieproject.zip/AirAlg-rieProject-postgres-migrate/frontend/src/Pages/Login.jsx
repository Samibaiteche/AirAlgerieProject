import React, { useState, useEffect } from "react";
import myImage1 from "../../public/images/image1.1.png";
import myImagee1 from "../../public/images/image1.png";
import myImage2 from "../../public/images/image2.png";
import myImage3 from "../../public/images/image3.png";
import myImage4 from "../../public/images/image4.png";
import GradientButton from "../components/GradientButton";
import { useNavigate } from "react-router-dom";
import { login } from "../services/apiServices";
import "../index.css"; // for additional custom CSS

const sleep = ms => new Promise(r => setTimeout(r, ms));

const Login = () => {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [errorMessage, setErrorMessage] = useState("");
  const [loading, setLoading] = useState(false); // Loading state
  const [isMounted, setIsMounted] = useState(false);
  const navigate = useNavigate();

  useEffect(() => {
    setIsMounted(true); // Trigger fade-in animation
  }, []);

  const handleUserChange = (e) => setUsername(e.target.value);
  const handlePasswordChange = (e) => setPassword(e.target.value);

  const handleLoginClick = async () => {
    if (!username || !password) {
      setErrorMessage(
        "Nom d'utilisateur ou mot de passe incorrect. Veuillez entrer des informations correctes."
      );
    } else {
      setErrorMessage("");
      setLoading(true); // Show "Vérification en cours..."

      // Simulate 3-second delay for verification (you can remove this if it's not needed)
      const fetchLogin = async () => {
        try {
          const response = await login({
            username: username,
            password: password,
          });
          localStorage.setItem("token", response.access);
          navigate("/", { replace: true });
        } catch (err) {
          if (err.response.status == 401) {
            setErrorMessage(
              "Nom d'utilisateur ou mot de passe incorrect. Veuillez entrer des informations correctes."
            );
          }
        } finally {
          setLoading(false); // Return to original button
        }
      }

      fetchLogin()
    }
  };

  return (
    <div
      className={`flex flex-col md:flex-row w-full h-screen items-center transition-opacity duration-1000 ease-in ${isMounted ? "opacity-100" : "opacity-0"}`}
    >
      {/* Left Side: Form */}
      <div className="w-full md:w-1/2 bg-white flex flex-col justify-center items-center mt-2 md:p-6 p-6 animate-fadeIn">
        <h1 className="font-poppins text-2xl md:text-3xl lg:text-4xl font-semibold md:font-bold mb-4 md:mb-4 mt-8 md:mt-0 transition-transform duration-500 ease-in-out transform hover:scale-105">
          Authentification
        </h1>
        <p className="font-poppins text-sm md:text-lg text-gray-400 mb-4 md:mb-8 text-center p-4">
          Comment démarrer avec Salaire Manager ?
        </p>

        {/* Error message */}
        {errorMessage && (
          <div className="flex items-center flex-col mb-6 md:mb-6">
            <img
              src={myImage4}
              alt="error icon"
              className="md:w-8 w-6 mb-2 animate-pulse"
            />
            <p className="font-poppins text-base md:text-lg text-red-500">
              {errorMessage}
            </p>
          </div>
        )}

        {/* Username Input */}
        <div className="flex items-center w-3/5 md:w-full max-w-md md:h-12 h-8 md:rounded-xl rounded-md bg-gray-200 md:mb-6 mb-6 transition-all duration-300 ease-in-out focus-within:ring-2 focus-within:ring-red-300">
          <img
            src={myImage2}
            alt="profile icon"
            className="md:w-6 w-4 md:ml-4 ml-2"
          />
          <input
            type="text"
            value={username}
            onChange={handleUserChange}
            placeholder="Nom d'utilisateur"
            className="flex-grow bg-gray-200 rounded-lg md:rounded-xl pl-3 md:pl-4 outline-none text-xs md:text-base"
          />
        </div>

        {/* Password Input */}
        <div className="flex items-center w-3/5 md:w-full max-w-md md:h-12 h-8 md:rounded-xl rounded-md bg-gray-200 md:mb-6 mb-6 transition-all duration-300 ease-in-out focus-within:ring-2 focus-within:ring-red-300">
          <img
            src={myImage3}
            alt="password icon"
            className="md:w-6 w-4 md:ml-4 ml-2"
          />
          <input
            type="password"
            value={password}
            onChange={handlePasswordChange}
            placeholder="Mot de passe"
            className="flex-grow bg-gray-200 rounded-lg md:rounded-xl pl-3 md:pl-4 outline-none text-xs md:text-base"
          />
        </div>

        {/* Login Button */}
        <div className="mb-8 md:mb-2 md:mt-2 ease-in-out transform animate-[pulse-scale_1s_infinite]">
          {loading ? (
            <button className="bg-white text-green-400 py-2 px-4 rounded-md" disabled>
              Vérification en cours...
            </button>
          ) : (
            <GradientButton handleClick={handleLoginClick} />
          )}
        </div>
      </div>

      {/* Right Side: Image with dezoom effect on hover */}
      <div className="w-1/2 hidden h-screen md:flex items-center">
        <img
          src={myImagee1}
          alt="welcome message"
          className="max-h-full w-full object-cover transform scale-100 transition-transform duration-500 ease-in-out hover:scale-95"
        />
      </div>

      {/* Smaller Screen Image with dezoom effect */}
      <div className="md:hidden w-full px-2">
        <img
          src={myImage1}
          alt="welcome message"
          className="transform scale-100 transition-transform duration-500 ease-in-out hover:scale-95"
        />
      </div>
    </div>
  );
};

export default Login;
