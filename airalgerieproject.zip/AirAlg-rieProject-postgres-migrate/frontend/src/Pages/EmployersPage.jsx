import React, { useEffect, useState } from "react";
import patternImage from "../../public/images/patern.png";
import { DataGrid } from "@mui/x-data-grid";
import "../index.css";
import {
  getDirection,
  getEmployeesData,
  getDirections,
} from "../services/apiServices";

const CustomLoadingOverlay = () => {
  return (
    <div style={{
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      height: '100%'
    }}>
      <span>Veuillez patienter un peu ...</span>
    </div>
  );
};

const EmployersPage = () => {
  const [employees, setEmployees] = useState([]);
  const [direction, setDirection] = useState({});
  const [directions, setDirections] = useState({});
  const [columns, setColumns] = useState([]);
  const [loading, setLoading] = useState(true); // Added loading state

  useEffect(() => {
    const fetchDirection = async () => {
      try {
        var res = await getDirection();
        setDirection(res);
      } catch (error) {
      }
    };

    const fetchDirections = async () => {
      try {
        var res = await getDirections();
        var dirs = {};
        res.forEach((d) => {
          dirs[d[0]] = d[1];
        });

        setDirections(dirs);
      } catch (error) {
      }
    };

    fetchDirection();
    fetchDirections();
  }, []);

  useEffect(() => {
    const fetchEmployees = async () => {
      setLoading(true); // Set loading to true before fetching
      try {
        const res = await getEmployeesData();
        const employees = res.map(e => ({
          id: e.id,
          name: e.name,
          category: e.category,
          gender: e.gender ? "Homme" : "Femme",
          direction: directions[e.id_direction],
          gross_salary: e.gross_salary,
          employer_contributions: e.employer_contributions,
          social_contributions: e.social_contributions,
          total_payroll: e.gross_salary + e.employer_contributions + e.social_contributions,
        }));
        setEmployees(employees);
      } catch (error) {
      } finally {
        setLoading(false); // Set loading to false after fetching
      }
    };

    if (Object.keys(directions).length > 0) {
      fetchEmployees();
    }
  }, [directions]);

  const updateColumns = () => {
    const screenWidth = window.innerWidth;

    let baseColumns = [
      { field: "name", headerName: "Nom", flex: 1, minWidth: 90, headerClassName: "header" },
      {
        field: "category",
        headerName: "Catégorie",
        minWidth: 90,
        flex: 1,
        headerClassName: "header",
      },
      {
        field: "total_payroll",
        headerName: "Salaire Total (DA)",
        minWidth: 90,
        flex: 1,
        headerClassName: "header",
      },
    ];

    if (screenWidth >= 1024) {
      baseColumns.push(
        { field: "direction", headerName: "Direction", minWidth: 90, flex: 1, headerClassName: "header" },
        { field: "gender", headerName: "Genre", minWidth: 90, flex: 1, headerClassName: "header" },
        {
          field: "gross_salary",
          headerName: "Salaire brut (DA)",
          minWidth: 90,
          flex: 1,
          headerClassName: "header"
        },
        {
          field: "employer_contributions",
          headerName: "Charges patronales (DA)",
          minWidth: 90,
          flex: 1,
          headerClassName: "header"
        },
        {
          field: "social_contributions",
          headerName: "Contributions sociales (DA)",
          minWidth: 90,
          flex: 1,
          headerClassName: "header"
        },
      );
    } else if (screenWidth >= 768) {
      baseColumns.push({ field: "gender", headerName: "Genre", minWidth: 90, flex: 1, headerClassName: "header" });
    }

    setColumns(baseColumns);
  };

  useEffect(() => {
    updateColumns(); // Call this to set initial columns
    window.addEventListener("resize", updateColumns);
    return () => window.removeEventListener("resize", updateColumns);
  }, []);

  return (
    <div
      style={{
        backgroundImage: `url(${patternImage})`,
        backgroundRepeat: "repeat",
        backgroundSize: "auto",
      }}
      className="bg-[#f5dfdf] bg-opacity-100 w-full h-screen font-poppins flex flex-col justify-around"
    >
      <div className="bg-gradient-to-b from-[#f21414] to-[#f97777] px-2 md:px-4 py-1 md:py-2 ml-3 md:ml-6 w-fit animate-fadeIn hover:scale-105  shadow-md hover:shadow-lg transition-shadow duration-300">
        <h2 className="font-poppins text-white text-sm sm:text-base md:text-lg">
          Direction: {direction.name}
        </h2>
      </div>
      <div className="w-[100%] h-[85%] flex justify-center">
        <div className="w-[90%] h-[90%]">
          <DataGrid
            rows={employees}
            columns={columns}
            loading={loading} // Use loading state
            components={{ LoadingOverlay: CustomLoadingOverlay }} // Specify custom loading overlay
            pageSizeOptions={[5, 10, 50]}
            initialState={{
              pagination: {
                paginationModel: { pageSize: 10, page: 0 },
              },
            }}
            disableSelectionOnClick
            sortingOrder={["desc", "asc"]}
            sx={{
              "& .MuiDataGrid-columnHeaders": {
                color: "white",
              },
              "& .MuiDataGrid-cell": {
                backgroundColor: "white",
              },
              "& .MuiDataGrid-viewport": {
                backgroundColor: "white",
              },
              "& ::-webkit-scrollbar": {
                width: "8px",
                height: "8px",
              },
              "& ::-webkit-scrollbar-thumb": {
                background: "linear-gradient(to bottom, #f21414, #f97777)",
                borderRadius: "4px",
              },
              "& ::-webkit-scrollbar-track": {
                backgroundColor: "#f0f0f0",
              },
              "& .MuiDataGrid-columnSeparator": {
                display: "none",
              },
            }}
          />
        </div>
      </div>
    </div>
  );
};

export default EmployersPage;
