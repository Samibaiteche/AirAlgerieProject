import React, { useRef, useState, useEffect } from "react";
import patternImage from '../../public/images/patern.png';
import pana from "../assets/pana.png";
import Pdffile from "./pdffile";
import { PDFExport } from '@progress/kendo-react-pdf';

const DownloadPv = () => {
  const [loading, setLoading] = useState(true); // State to control loading
  const pdfExportComponent = useRef(null);

  // Helper function to get today's date in 'YYYY-MM-DD' format
  const getCurrentDate = () => {
    const today = new Date();
    const year = today.getFullYear();
    const month = String(today.getMonth() + 1).padStart(2, '0');
    const day = String(today.getDate()).padStart(2, '0');
    return `${year}-${month}-${day}`;
  };

  // Handle PDF download on click
  const handleDownloadClick = () => {
    if (pdfExportComponent.current) {
      pdfExportComponent.current.save();
    }
  };

  // Effect to handle the loading state
  useEffect(() => {
    const timer = setTimeout(() => {
      setLoading(false); // Change loading state after 2 seconds
    }, 3500);

    return () => clearTimeout(timer); // Cleanup timer on unmount
  }, []);

  return (
    <div
      style={{
        backgroundImage: `url(${patternImage})`,
        backgroundRepeat: 'repeat',
        backgroundSize: 'auto',
      }}
      className='bg-[#f5dfdf] bg-opacity-100 w-full h-screen flex flex-col justify-center items-center'
    >
      <div className="bg-white h-[50%] w-[90%] sm:h-[50%] sm:w-[80%] md:h-[50%] md:w-[75%] lg:h-[50%] lg:w-[60%] xl:h-[50%] xl:w-[50%] rounded-2xl shadow-2xl flex justify-center items-center">
        <div className="h-[80%] w-full flex flex-col sm:flex-row justify-around items-center">
          <img src={pana} className="w-[60%] nimate-fadeIn hover:scale-105 duration-300 sm:w-[40%] h-auto mb-4 sm:mb-0" alt="" />
          <div className="w-[100%] sm:w-[50%] h-full text-center flex flex-col justify-around items-center">
            <p className="font-bold text-xl sm:text-2xl md:text-3xl text-center animate-fadeIn hover:scale-105 duration-300">Télécharger PV</p>
            <p className="text-center font-semibold text-base sm:text-lg md:text-xl animate-fadeIn hover:scale-105 duration-300">
              Si vous voulez télécharger une version pdf du tableau de bord, cliquez ici
            </p>
            {loading ? (
              <button
                className="w-[80%] py-1 md:py-2 px-4 md:px-4 transform animate-[pulse-scale_1s_infinite]   font-semibold text-green-400"
                disabled
              >
                Préparation du fichier ...
              </button>
            ) : (
              <button
                onClick={handleDownloadClick}
                className="w-[80%] animate-fadeIn hover:scale-105 shadow-md hover:shadow-lg transition-shadow duration-300 md:w-fit py-1 md:py-2 px-4 md:px-4 bg-gradient-to-b from-[#f21414] to-[#f97777] rounded-xl md:rounded-3xl font-bold text-white"
              >
                Télécharger
              </button>
            )}
          </div>
        </div>
      </div>
      <div className="w-full mt-8" style={{ position: 'absolute', left: '-9999px' }}>
        <PDFExport ref={pdfExportComponent} fileName={`Pv_Général_${getCurrentDate()}.pdf`}>
          <Pdffile />
        </PDFExport>
      </div>
    </div>
  );
};

export default DownloadPv;
