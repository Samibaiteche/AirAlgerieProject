import React from "react";
import patternImage from '../../public/images/patern.png';
import DeconnexionImage from "../assets/DeconnexionImage.png";
import { disconnect } from "../utils";
import { useNavigate } from "react-router-dom";

const Deconnexion = () => {
  const navigate = useNavigate();
  const handleDeconnexionClick = () => {
    disconnect();
  };

  const handleAnnulerClick = () => {
    navigate('/graphes');
  };

  return (
    <div
      style={{
        backgroundImage: `url(${patternImage})`,
        backgroundRepeat: 'repeat',
        backgroundSize: 'auto',
      }}
      className="bg-[#f5dfdf] bg-opacity-100 w-full h-screen flex justify-center items-center"
    >
      <div className="bg-white h-[50%] w-[90%] sm:h-[50%] sm:w-[80%] md:h-[50%] md:w-[80%] lg:h-[50%] lg:w-[65%] xl:h-[50%] xl:w-[50%] rounded-2xl shadow-2xl flex justify-center items-center">
        <div className="h-[80%] w-full flex flex-col sm:flex-row justify-around items-center">
          <img
            src={DeconnexionImage}
            className="w-[60%] sm:w-[40%] h-auto mb-4 sm:mb-0 animate-fadeIn hover:scale-105  duration-300"
            alt="Déconnexion"
          />
          <div className="w-full sm:w-[50%] sm:h-full text-center flex flex-col justify-around items-center">
            <p className="font-bold animate-fadeIn hover:scale-105  duration-300 text-xl sm:text-2xl md:text-3xl">Attention !</p>
            <p className="text-center animate-fadeIn hover:scale-105  duration-300 font-semibold text-base sm:text-lg md:text-xl">
              Est-ce que vous voulez vraiment vous déconnecter ?
            </p>
            <div className="flex flex-col lg:flex-row justify-between w-full sm:gap-4 mt-4 px-8 sm:px-0 ">
              <button
                onClick={handleAnnulerClick}
                className="hidden animate-fadeIn hover:scale-105  shadow-md hover:shadow-lg transition-shadow duration-300 lg:block py-1 md:py-2 px-2 md:px-4 border-2 border-red-500 rounded-xl md:rounded-3xl font-bold text-red-500 bg-clip-text mb-4 sm:mb-0"
              >
                Annuler
              </button>
              <button
                onClick={handleDeconnexionClick}
                className="py-1 animate-fadeIn hover:scale-105  shadow-md hover:shadow-lg transition-shadow duration-300 md:py-2 px-2 md:px-4 bg-gradient-to-b from-[#f21414] to-[#f97777] rounded-xl md:rounded-3xl font-bold text-white"
              >
                Déconnecter
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Deconnexion;
