import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom"; // Import useNavigate for routing
import myImage1 from "../../public/images/image5.png"; // AIR ALGERIE logo
import myImage2 from "../../public/images/image6.png"; // Bienvenue icon
import myImage3 from "../../public/images/image7.png"; // Graphes icon
import myImage4 from "../../public/images/image8.png"; // Tableaux icon
import myImage5 from "../../public/images/image9.png"; // Imprimer PV icon
import myImage6 from "../../public/images/image10.png"; // Déconnexion icon
import hoverImage3 from "../../public/images/image11.png";
import hoverImage4 from "../../public/images/image12.png";
import hoverImage5 from "../../public/images/image13.png";
import hoverImage6 from "../../public/images/image14.png";
import { getAdmin } from "../services/apiServices";

const Sidebar = () => {
    const [activeButton, setActiveButton] = useState(null);
    const navigate = useNavigate(); // Initialize useNavigate for route navigation
    const [admin, setAdmin] = useState({});

    useEffect(() => {
        const fetchAdmin = async () => {
            try {
                var res = await getAdmin();
                setAdmin(res);
            } catch (error) { }
        };

        fetchAdmin();
    }, []);

    return (
        <div className="flex flex-col w-28 sm:w-48 md:w-60 h-screen lg:w-64 bg-gradient-to-b from-[#f21414] to-[#f97777] p-2 md:p-4 min-h-screen transition-all duration-500 ease-in-out">
            {/* AIR ALGERIE Section */}
            <div className="flex flex-col items-center mt-16 sm:mt-0 transition-transform duration-500 hover:scale-105">
                <img
                    src={myImage1}
                    alt="AIR ALGERIE"
                    className="sm:w-32 sm:h-32 w-24 h-24 "
                />
                <h1 className="font-protest text-white text-base md:text-xl sm:text-lg -mt-8">
                    AIR ALGERIE
                </h1>
            </div>

            {/* Bienvenue Section */}
            <div className="flex flex-col items-center mt-6 mb-16 sm:mb-0 transition-transform duration-500 hover:scale-105">
                <img
                    src={myImage2}
                    alt="Bienvenue"
                    className="sm:w-20 sm:h-20 w-16 h-16 mb-1"
                />
                <h2 className="font-protest text-white text-base md:text-xl sm:text-lg">
                    Bienvenue
                </h2>
                <h2 className="font-protest text-white md:text-xl sm:text-lg text-base">
                    {admin.username || "UserName"}
                </h2>
            </div>

            {/* Horizontal Line */}
            <hr className="border-t-2 border-white mt-10 mb-3 w-full" />

            {/* Menu Items */}
            <nav className="flex flex-col w-full">
                <MenuItem
                    icon={myImage3}
                    hoverIcon={hoverImage3}
                    label="Graphes"
                    isActive={activeButton === "Graphes"}
                    setActive={() => {
                        setActiveButton("Graphes");
                        navigate("/graphes"); // Navigate to /graphes when clicked
                    }}
                />
                <MenuItem
                    icon={myImage4}
                    hoverIcon={hoverImage4}
                    label="Tableaux"
                    isActive={activeButton === "Tableaux"}
                    setActive={() => {
                        setActiveButton("Tableaux");
                        navigate("/tableaux"); // Navigate to /tableaux when clicked
                    }}
                />
                <MenuItem
                    icon={myImage5}
                    hoverIcon={hoverImage5}
                    label="Télécharger PV"
                    isActive={activeButton === "Télécharger PV"}
                    setActive={() => {
                        setActiveButton("Télécharger PV");
                        navigate("/téléchargerpv"); // Navigate to /téléchargerpv when clicked
                    }}
                />
                <div className="mt-auto">
                    <MenuItem
                        icon={myImage6}
                        hoverIcon={hoverImage6}
                        label="Déconnexion"
                        isActive={activeButton === "Déconnexion"}
                        setActive={() => {
                            setActiveButton("Déconnexion");
                            navigate("/deconnexion"); // Navigate to /deconnexion when clicked
                        }}
                    />
                </div>
            </nav>

            {/* Bottom Horizontal Line */}
            <hr className="border-t-2 border-white mt-8 mb-4 w-full" />
        </div>
    );
};

const MenuItem = ({ icon, hoverIcon, label, isActive, setActive }) => {
    const [isHovered, setIsHovered] = useState(false);

    return (
        <button
            className={`flex items-center w-full space-x-2 md:space-x-4 md:py-3 py-2 md:px-4 px-2 my-1 md:my-2 text-base md:text-lg font-medium font-poppins
      hover:bg-white hover:text-red-500 focus:bg-white focus:text-red-500 rounded transition-all duration-300 ease-in-out
      ${isActive ? "bg-white text-red-500 shadow-lg" : ""}`}
            onMouseEnter={() => setIsHovered(true)}
            onMouseLeave={() => setIsHovered(false)}
            onClick={setActive}
        >
            <img
                src={isActive || isHovered ? hoverIcon : icon}
                alt={label}
                className="md:w-8 md:h-8 sm:w-6 sm:h-6 w-4 h-4 hidden sm:block transition-transform duration-300 ease-in-out hover:scale-110"
            />
            <span
                className={`sm:text-base text-xs ${isActive || isHovered ? "text-red-500" : "text-white"
                    } transition-transform duration-300 ease-in-out hover:scale-105`}
            >
                {label}
            </span>
        </button>
    );
};

export default Sidebar;
