import React, { useEffect, useState } from "react";
import {
    getNumEmployees,
    getChartData,
    getDirection,
    getDirections,
} from "../services/apiServices";
import Chartpdf from "../components/chartpdf";

const PdfFile = () => {
    const [direction, setDirection] = useState({});
    const [chartData, setChartData] = useState({});
    const [numEmployees, setNumEmployees] = useState(null);

    const currentDate = new Date();
    const formattedDate = `${currentDate
        .getDate()
        .toString()
        .padStart(2, "0")}/${(currentDate.getMonth() + 1)
            .toString()
            .padStart(2, "0")}/${currentDate.getFullYear()}`;

    useEffect(() => {
        const fetchData = async () => {
            try {
                var data = await getDirection();
                setDirection(data);

                data = await getNumEmployees();
                setNumEmployees(data);
            } catch (error) {
            }
        };

        const fetchChartData = async () => {
            try {
                const res = await getChartData();
                setChartData(res);
            } catch (error) {
            }
        };

        fetchData();
        fetchChartData();
    }, []);

    return (
        <div className={`relative w-full h-screen`}>
            <div className="bg-white w-full h-full pt-6">
                <div className="px-4 py-1 ml-6 w-fit mb-8">
                    <h2 className="font-poppins font-bold text-black sm:text-2xl text-base">
                        PV detaille de la direction :
                    </h2>
                </div>
                <div className="px-4 py-1 ml-6 w-fit">
                    <h2 className="font-poppins text-black text-lg sm:text-base">
                        Direction: {direction?.name || "Loading..."}
                    </h2>
                </div>
                <div className="bg-white px-4 py-1 ml-6 mt-2 w-fit flex">
                    <h2 className="font-poppins font-normal text-black text-lg sm:text-md mt-1">
                        Employés: {numEmployees}
                    </h2>
                </div>
                <div className="bg-white px-4 py-1 ml-6 mt-2 w-fit flex mb-8">
                    <h2 className="font-poppins font-normal text-black text-lg sm:text-md mt-1">
                        Date: {formattedDate}
                    </h2>
                </div>

                <div className="px-6 py-4 ml-8" style={{ overflow: 'hidden' }}>
                    {/* Conditionally render the chart if chartData is available */}
                    {chartData ? <Chartpdf chartData={chartData} /> : "Loading chart data..."}
                </div>
            </div>
        </div>
    );
};

export default PdfFile;
