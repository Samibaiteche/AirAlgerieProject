import React, { useEffect, useState } from "react";
import patternImage from "../../public/images/patern.png";
import profile from "../../public/images/profile.png";
import dateicon from "../../public/images/date.png";
import FilterButton from "../components/FilterButton";
import Chart from "../components/chart";
import downwhite from "../../public/images/downwhite.png";
import downred from "../../public/images/downred.png";
import {
  filterChart,
  getChartData,
  getDirection,
  getDirections,
  getNumEmployees,
} from "../services/apiServices";

const HomePage = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [isOpenSecondMois, setIsOpenSecondMois] = useState(false);
  const [isOpenGenre, setIsOpenGenre] = useState(false);
  const [isOpenCategorie, setIsOpenCategorie] = useState(false);
  const [isOpenDirection, setIsOpenDirection] = useState(false);
  const [direction, setDirection] = useState({});
  const [directions, setDirections] = useState([]);
  const [chartData, setChartData] = useState([]);
  const [filterData, setFilterData] = useState({});
  const [numEmployees, setNumEmployees] = useState(null);
  const months = [
    "Janvier",
    "Février",
    "Mars",
    "Avril",
    "Mai",
    "Juin",
    "Juillet",
    "Août",
    "Septembre",
    "Octobre",
    "Novembre",
    "Décembre",
  ];

  const genres = ["Homme", "Femme"];
  const categories = ["cadre", "maitrise", "executant"];
  const toggleDropdown = () => {
    setIsOpen(!isOpen);
  };
  const toggleDropdownSecondMois = () => {
    setIsOpenSecondMois(!isOpenSecondMois);
  };

  const [selectedMonth, setSelectedMonth] = useState("Mois");
  const [selectedSecondMonth, setSelectedSecondMonth] = useState("Mois");
  const [selectedGenre, setSelectedGenre] = useState("Genre");
  const [selectedCategorie, setSelectedCategorie] = useState("Catégorie");
  const [selectedDirection, setSelectedDirection] = useState("Direction");
  const [startingYear, setStartingYear] = useState("");
  const [endingYear, setEndingYear] = useState("");

  const toggleDropdownGenre = () => setIsOpenGenre(!isOpenGenre);
  const toggleDropdownCategorie = () => setIsOpenCategorie(!isOpenCategorie);
  const toggleDropdownDirection = () => setIsOpenDirection(!isOpenDirection);

  const selectStartingYear = (year) => {
    setFilterData((prevData) => ({
      ...prevData,
      starting_year: year,
    }));
  };

  const selectEndingYear = (year) => {
    setFilterData((prevData) => ({
      ...prevData,
      ending_year: year,
    }));
  };

  const selectMonth = (mois) => {
    setSelectedMonth(mois);
    setFilterData((prevData) => ({
      ...prevData,
      starting_month: months.indexOf(mois) + 1,
    }));
    setIsOpen(false);
  };

  const selectSecondMonth = (mois) => {
    setSelectedSecondMonth(mois);
    setFilterData((prevData) => ({
      ...prevData,
      ending_month: months.indexOf(mois) + 1,
    }));
    setIsOpenSecondMois(false);
  };

  const selectGenre = (genre) => {
    setSelectedGenre(genre);
    var gender = genre === "Homme";
    setFilterData((prevData) => ({
      ...prevData,
      gender: gender,
    }));
    setIsOpenGenre(false);
  };

  const selectCategorie = (categorie) => {
    setSelectedCategorie(categorie);
    setFilterData((prevData) => ({
      ...prevData,
      category: categorie,
    }));
    setIsOpenCategorie(false);
  };

  const selectDirection = (dir) => {
    var d = directions.find((d) => d[0] == dir);
    setSelectedDirection(d[1]);
    setFilterData((prevData) => ({
      ...prevData,
      direction: d[0],
    }));
    setIsOpenDirection(false);
  };
  const [isPopupOpen, setIsPopupOpen] = useState(false);

  const togglePopup = () => setIsPopupOpen(!isPopupOpen);

  const currentDate = new Date();
  const formattedDate = `${currentDate
    .getDate()
    .toString()
    .padStart(2, "0")}/${(currentDate.getMonth() + 1)
    .toString()
    .padStart(2, "0")}/${currentDate.getFullYear()}`;

  useEffect(() => {
    const fetchData = async () => {
      try {
        var data = await getDirection();
        setDirection(data);

        data = await getDirections();
        setDirections(data);

        data = await getNumEmployees();
        setNumEmployees(data);
      } catch (error) {}
    };

    const fetchChartData = async () => {
      try {
        const res = await getChartData();
        setChartData(res);
      } catch (error) {}
    };

    fetchData();
    fetchChartData();
  }, []);

  const runFilter = async () => {
    try {
      var res = await filterChart(filterData);
      setChartData(res);
    } catch (error) {}
  };

  return (
    <div
      className={`relative w-full h-screen ${
        isPopupOpen ? "overflow-hidden animate-fadeIn" : ""
      }`}
      style={{
        backgroundImage: `url(${patternImage})`,
        backgroundRepeat: "repeat",
        backgroundSize: "auto",
      }}
    >
      {isPopupOpen && (
        <div className="fixed inset-0 bg-black opacity-50 z-10 animate-fadeIn"></div>
      )}

      <div className="bg-[#f5dfdf] bg-opacity-100 w-full h-full pt-6">
        <div className="bg-gradient-to-b from-[#f21414] to-[#f97777] px-2  md:px-4 py-1 md:py-2 ml-3 md:ml-6 w-fit animate-fadeIn hover:scale-105  shadow-md hover:shadow-lg transition-shadow duration-300">
          <h2 className="font-poppins text-white text-sm sm:text-base md:text-lg cursor-default">
            Direction: {direction.name}
          </h2>
        </div>
        <div className="flex flex-col md:flex-row md:-mt-3">
          <div className="bg-white hover:scale-105 px-2 md:px-4 py-1 md:py-2 ml-3 md:ml-6 mt-3 md:mt-6 w-fit flex  shadow-md hover:shadow-lg transition-shadow duration-300">
            <h2 className="font-poppins font-normal text-black text-sm sm:text-base md:text-lg mt-1">
              Employés
            </h2>
            <img
              src={profile}
              alt="profile"
              className="w-5 animate-pulse h-5 md:w-6 md:h-6 ml-2 md:ml-3 mr-3 md:mr-7 mt-1"
            />
            <h2 className="font-poppins font-bold text-black text-sm sm:text-base md:text-lg mt-1">
              {numEmployees}
            </h2>
          </div>
          <div className="bg-white px-2 md:px-4 py-1 md:py-2 ml-3 md:ml-6 mt-3 hover:scale-105 md:mt-6 w-fit flex shadow-md hover:shadow-lg transition-shadow duration-300">
            <h2 className="font-poppins font-normal text-black text-sm sm:text-base md:text-lg mt-1">
              Date
            </h2>
            <img
              src={dateicon}
              alt="date icon"
              className="w-5 animate-pulse h-5 md:w-6 md:h-6 ml-2 md:ml-3 mr-3 md:mr-7 mt-1"
            />
            <h2 className="font-poppins font-bold text-black text-sm sm:text-base md:text-lg mt-1">
              {formattedDate}
            </h2>
          </div>
          <div className="w-fit ml-4 mt-4 md:ml-auto md:mr-4 md:mt-8">
            <FilterButton
              onClick={togglePopup}
              className="transition-transform transform hover:scale-105"
            />
          </div>
        </div>

        <div className="animate-fadeIn">
          <Chart chartData={chartData} />
        </div>
        {isPopupOpen && (
          <div className="fixed inset-0  flex items-center justify-center z-20 shadow-md hover:shadow-xl  transition-all duration-300">
            <div className="bg-[#fff6f1] transition-transform duration-1000 ease-in-out animate-fadeIn rounded-lg shadow-lg md:ml-[15%] flex flex-col items-center justify-center py-6 px-2 md:w-6/12 w-8/12">
              <div className="w-fit  hover:scale-105  text-lg bg-gradient-to-r from-[#f21414] to-[#f97777] text-white font-bold font-poppins py-2 px-6 rounded-xl shadow-md hover:shadow-lg transition-shadow duration-300 cursor-pointer -mt-10 mb-4">
                <h1 className="text-center">Filter</h1>
              </div>

              <h2 className="font-poppins md:font-bold font-semibold md:text-lg text-base mb-4">
                Veuillez choisir :
              </h2>
              <div className="mb-4 md:flex justify-between w-full px-4">
                <div className="w-full md:w-2/3 justify-start">
                  <p className="mb-2">Date du début</p>
                  <div className="md:w-9/12 w-11/12 justify-between flex flex-row">
                    <div
                      className="w-fit text-base hover:scale-105 bg-gradient-to-r from-[#f21414] to-[#f97777] text-white flex items-center font-medium md:font-semibold font-poppins py-1 md:px-4 px-1 sm:px-3 rounded-xl shadow-md hover:shadow-lg transition-shadow duration-300 cursor-pointer"
                      onClick={toggleDropdown}
                    >
                      <h1 className="text-center ml-1">{selectedMonth}</h1>
                      <img
                        src={downwhite}
                        alt="down"
                        className="w-5 h-5 ml-2 mr-2 cursor-pointer"
                      />
                    </div>
                    {isOpen && (
                      <div className="absolute  bg-white text-black w-fit shadow-lg z-10 mt-8 max-h-24 overflow-y-auto">
                        {months.map((moisItem, index) => (
                          <div
                            key={index}
                            className="hover:bg-gray-200 cursor-pointer py-1 px-2"
                            onClick={() => selectMonth(moisItem)}
                          >
                            {moisItem}
                          </div>
                        ))}
                      </div>
                    )}

                    <div className="w-fit hover:scale-105 flex items-center text-base  border-2 border-red-500 text-red-500 font-medium md:font-semibold font-poppins py-1 md:px-4 px-1  sm:px-3 rounded-xl shadow-md hover:shadow-lg transition-shadow duration-300">
                      <input
                        type="number"
                        className="text-center bg-transparent border-none outline-none text-red-500 w-20 font-semibold"
                        placeholder="Année"
                        value={startingYear}
                        onChange={(e) => setStartingYear(e.target.value)}
                        onBlur={() =>
                          selectStartingYear(parseInt(startingYear))
                        }
                        onFocus={(e) => (e.target.placeholder = "")}
                      />
                    </div>
                  </div>
                </div>
                <div className="w-1/3 justify-end  mt-2 md:mt-0">
                  <p className="mb-2">Genre</p>
                  <div
                    onClick={toggleDropdownGenre}
                    className="w-fit hover:scale-105 flex items-center text-base border-2 border-red-500 text-red-500 font-medium md:font-semibold font-poppins py-1 md:px-4 px-4 rounded-xl shadow-md hover:shadow-lg transition-shadow duration-300"
                  >
                    <h1 className="text-center">{selectedGenre}</h1>
                    <img
                      src={downred}
                      alt="down"
                      className="w-5 h-5 ml-2 mr-2 cursor-pointer"
                    />
                  </div>
                  {isOpenGenre && (
                    <div className="absolute  bg-white text-black w-fit shadow-lg -mt-1 z-10 max-h-24 overflow-y-auto">
                      {genres.map((genreItem, index) => (
                        <div
                          key={index}
                          className="hover:bg-gray-200 cursor-pointer py-1 px-2"
                          onClick={() => selectGenre(genreItem)}
                        >
                          {genreItem}
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              </div>
              <div className="mb-4 md:flex justify-between w-full px-4">
                <div className="w-full md:w-2/3 justify-start">
                  <p className="mb-2">Date du fin</p>
                  <div className="md:w-9/12 w-11/12 justify-between flex flex-row">
                    <div
                      className="w-fit text-base hover:scale-105  bg-gradient-to-r from-[#f21414] to-[#f97777] text-white flex items-center font-medium md:font-semibold font-poppins py-1 md:px-4 px-1  sm:px-3 rounded-xl shadow-md hover:shadow-lg transition-shadow duration-300 cursor-pointer"
                      onClick={toggleDropdownSecondMois}
                    >
                      <h1 className="text-center ml-1">
                        {selectedSecondMonth}
                      </h1>
                      <img
                        src={downwhite}
                        alt="down"
                        className="w-5 h-5 ml-2 mr-2 cursor-pointer"
                      />
                    </div>
                    {isOpenSecondMois && (
                      <div className="absolute  bg-white text-black w-fit shadow-lg z-10 mt-8 max-h-24 overflow-y-auto">
                        {months.map((moisItem, index) => (
                          <div
                            key={index}
                            className="hover:bg-gray-200 cursor-pointer py-1 px-2"
                            onClick={() => selectSecondMonth(moisItem)}
                          >
                            {moisItem}
                          </div>
                        ))}
                      </div>
                    )}

                    <div className="w-fit hover:scale-105 flex items-center text-base  border-2 border-red-500 text-red-500 font-medium md:font-semibold font-poppins py-1 md:px-4 sm:px-3 px-1 rounded-xl shadow-md hover:shadow-lg transition-shadow duration-300">
                      <input
                        type="number"
                        className="text-center bg-transparent border-none outline-none text-red-500 w-20 font-semibold"
                        placeholder="Année"
                        value={endingYear} // Bind the value to endingYear state
                        onChange={(e) => setEndingYear(e.target.value)} // Update the state on change
                        onBlur={() => selectEndingYear(parseInt(endingYear))} // Pass the value to selectEndingYear on blur
                        onFocus={(e) => (e.target.placeholder = "")} // Clear the placeholder on focus
                      />
                    </div>
                  </div>
                </div>
                <div className="w-1/3 justify-end mt-2 md:mt-0">
                  <p className="mb-2">Catégorie</p>
                  <div
                    onClick={toggleDropdownCategorie}
                    className="w-fit flex hover:scale-105 items-center text-base  border-2 border-red-500 text-red-500 font-medium md:font-semibold font-poppins py-1 md:px-4 px-4 rounded-xl shadow-md hover:shadow-lg transition-shadow duration-300"
                  >
                    <h1 className="text-center">{selectedCategorie}</h1>
                    <img
                      src={downred}
                      alt="down"
                      className="w-5 h-5 ml-2 mr-2 cursor-pointer"
                    />
                  </div>
                  {isOpenCategorie && (
                    <div className="absolute  bg-white text-black w-fit shadow-lg z-10  max-h-24 overflow-y-auto  -mt-1">
                      {categories.map((categorieItem, index) => (
                        <div
                          key={index}
                          className="hover:bg-gray-200 cursor-pointer py-1 px-2"
                          onClick={() => selectCategorie(categorieItem)}
                        >
                          {categorieItem}
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              </div>
              {(direction.name === "Direction Générale" ||
                direction.name === "Ressources Humaines") && (
                <div className="mb-4 flex justify-between w-full px-4">
                  <div className=" justify-start ">
                    <p className="mb-2">Direction</p>
                    <div
                      onClick={toggleDropdownDirection}
                      className="w-fit hover:scale-105 text-base  bg-gradient-to-r from-[#f21414] to-[#f97777] text-white flex items-center font-medium md:font-semibold font-poppins py-1 md:px-4 px-3 rounded-xl shadow-md hover:shadow-lg transition-shadow duration-300"
                    >
                      <h1 className="text-center">{selectedDirection}</h1>
                      <img
                        src={downwhite}
                        alt="down"
                        className="w-5 h-5 ml-2 mr-2 cursor-pointer"
                      />
                    </div>
                    {isOpenDirection && (
                      <div className="absolute  bg-white text-black w-[50%] md:w-fit shadow-lg z-10 max-h-24 overflow-y-auto  -mt-1">
                        {directions.map((directionItem, index) => (
                          <div
                            key={index}
                            className="hover:bg-gray-200 cursor-pointer py-1 px-2"
                            onClick={() => selectDirection(directionItem[0])}
                          >
                            {directionItem[1]}
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                </div>
              )}

              <div className="flex justify-between items-center w-full md:w-9/12 mt-6 md:px-16 sm:px-8 px-2">
                <button
                  onClick={() => {
                    // Close all dropdowns
                    setIsOpen(false);
                    setIsOpenSecondMois(false);
                    setIsOpenGenre(false);
                    setIsOpenCategorie(false);
                    setIsOpenDirection(false);
                    setStartingYear(""); // Reset starting year
                    setEndingYear(""); // Reset ending year

                    // Optional: Reset any other filter-related states here if necessary
                    // For example, if you have selected values for months, genres, etc., reset them

                    // Close the popup
                    togglePopup();
                    window.location.reload();
                  }}
                  className="border-2 shadow-md hover:shadow-xl transition-all duration-300 hover:scale-105 border-red-500 text-red-500 font-poppins font-normal md:font-medium px-3 md:px-4 py-2 md:py-2 rounded-xl md:rounded-2xl"
                >
                  défiltrer
                </button>
                <button
                  onClick={() => {
                    runFilter();
                    togglePopup();
                  }}
                  className="bg-gradient-to-r shadow-md hover:shadow-xl hover:scale-105 transition-all duration-300 from-[#f21414] to-[#f97777] text-white font-poppins  font-normal md:font-medium px-3 md:px-4 py-2 md:py-2 rounded-xl md:rounded-2xl"
                >
                  Appliquer
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default HomePage;
