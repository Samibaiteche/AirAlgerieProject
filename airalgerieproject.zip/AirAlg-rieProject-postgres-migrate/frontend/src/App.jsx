import React from 'react';
import { BrowserRouter as Router, Route, Routes, Outlet, RouterProvider, createBrowserRouter, createRoutesFromElements } from 'react-router-dom';
import Sidebar from './Pages/Sidebar'; // Import Sidebar component
import HomePage from './Pages/HomePage'; // Import HomePage
import Login from './Pages/Login';
import EmployersPage from './Pages/EmployersPage';
import DownloadPv from './Pages/DownloadPv';
import Deconnexion from './Pages/Deconnexion';
import ProtectedRoute from './protected_route';


const ProtectedLayout = () => {
  return (
    <div className="flex h-screen">
      <div className="">
        <Sidebar username="UserName" />
      </div>
      <div className="flex-grow">
        <Outlet />  {/* Outlet juste pour les protected routes */}
      </div>
    </div>
  );
};

const App = () => {
  const router = createBrowserRouter(
    createRoutesFromElements(
      <Route path='/'>
        <Route path="login" element={<Login />} />
        <Route element={<ProtectedRoute />}>
          <Route element={<ProtectedLayout />}>
            <Route index element={<HomePage />} />
            <Route path="/graphes" element={<HomePage />} />
            <Route path="/tableaux" element={<EmployersPage />} />
            <Route path="/téléchargerpv" element={<DownloadPv />} />
            <Route path="/deconnexion" element={<Deconnexion />} />
          </Route>
        </Route>
      </Route>
    ))
  return (
    <RouterProvider router={router} />
  );
};

export default App;
