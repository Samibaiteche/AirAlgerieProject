import React, { useEffect, useState } from "react";
import {
  AreaChart,
  Area,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
} from "recharts";

const Chart = ({ chartData }) => {
  const formatYAxis = (tick) => {
    return `${(tick / 1000000).toFixed(1)}M`;
  };

  // State to track window width
  const [isMdScreen, setIsMdScreen] = useState(window.innerWidth >= 768);

  useEffect(() => {
    const handleResize = () => {
      setIsMdScreen(window.innerWidth >= 768);
    };

    window.addEventListener("resize", handleResize);

    // Cleanup the event listener on component unmount
    return () => {
      window.removeEventListener("resize", handleResize);
    };
  }, []);

  return (
    <div style={{ width: "100%" }}>
      <div className="flex flex-col md:flex-row p-4 justify-between ml-4 mr-4 gap-2">
        {/* First Chart */}
        <div className="flex flex-col items-start md:w-1/3 transition-transform duration-300 ease-in-out hover:scale-y-105">
          <h3 className="font-poppins font-semibold mb-1 whitespace-nowrap">
            Salaire brut
          </h3>
          <ResponsiveContainer
            width="100%"
            height={window.innerWidth < 768 ? 100 : 175}
            className="bg-white py-1 shadow-lg hover:shadow-2xl"
          >
            <AreaChart
              data={chartData}
              syncId="chartSync"
              margin={{ top: 10, right: 10, left: 0, bottom: 0 }}
            >
              <XAxis dataKey="name" />
              <YAxis tickFormatter={formatYAxis} />
              {isMdScreen && <Tooltip />} {/* Conditionally render Tooltip */}
              {!isMdScreen && <CartesianGrid strokeDasharray="5 5" />}
              <Area
                type="monotone"
                dataKey="sb"
                stroke="#00CED1"
                fill="#00CED155"
              />
            </AreaChart>
          </ResponsiveContainer>
        </div>

        {/* Second Chart */}
        <div className="flex flex-col items-start md:w-1/3 transition-transform duration-300 ease-in-out hover:scale-y-105">
          <h3 className="font-poppins font-semibold mb-1 whitespace-nowrap">
            Charges patronales
          </h3>
          <ResponsiveContainer
            width="100%"
            height={window.innerWidth < 768 ? 100 : 175}
            className="bg-white py-1 shadow-lg hover:shadow-2xl"
          >
            <AreaChart
              data={chartData}
              syncId="chartSync"
              margin={{ top: 10, right: 10, left: 0, bottom: 0 }}
            >
              <XAxis dataKey="name" />
              <YAxis tickFormatter={formatYAxis} />
              {isMdScreen && <Tooltip />} {/* Conditionally render Tooltip */}
              {!isMdScreen && <CartesianGrid strokeDasharray="5 5" />}
              <Area
                type="monotone"
                dataKey="cp"
                stroke="#B4EEB4"
                fill="#B4EEB477"
              />
            </AreaChart>
          </ResponsiveContainer>
        </div>

        {/* Third Chart */}
        <div className="flex flex-col items-start md:w-1/3 transition-transform duration-300 ease-in-out hover:scale-y-105">
          <h3 className="font-poppins font-semibold mb-1 whitespace-nowrap">
            Contributions sociales
          </h3>
          <ResponsiveContainer
            width="100%"
            height={window.innerWidth < 768 ? 100 : 175}
            className="bg-white py-1 shadow-lg hover:shadow-2xl"
          >
            <AreaChart
              data={chartData}
              syncId="chartSync"
              margin={{ top: 10, right: 10, left: 0, bottom: 0 }}
            >
              <XAxis dataKey="name" />
              <YAxis tickFormatter={formatYAxis} />
              {isMdScreen && <Tooltip />} {/* Conditionally render Tooltip */}
              {!isMdScreen && <CartesianGrid strokeDasharray="5 5" />}
              <Area
                type="monotone"
                dataKey="cs"
                stroke="#FF6666"
                fill="#FF666655"
              />
            </AreaChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Fourth Chart */}
      <div className="ml-8 mr-8 mt-2">
        <div className="flex flex-col items-start w-full transition-transform duration-300 ease-in-out hover:scale-y-105">
          <h3 className="font-poppins font-semibold mb-1 whitespace-nowrap">
            Salaire total
          </h3>
          <ResponsiveContainer
            width="100%"
            height={window.innerWidth < 768 ? 100 : 175}
            className="bg-white py-1 shadow-lg hover:shadow-2xl"
          >
            <AreaChart
              data={chartData}
              syncId="chartSync"
              margin={{ top: 10, right: 10, left: 0, bottom: 0 }}
            >
              <XAxis dataKey="name" />
              <YAxis tickFormatter={formatYAxis} />
              {isMdScreen && <Tooltip />} {/* Conditionally render Tooltip */}
              {!isMdScreen && <CartesianGrid strokeDasharray="5 5" />}
              <Area
                type="monotone"
                dataKey="st"
                stroke="#660066"
                fill="#66006655"
              />
            </AreaChart>
          </ResponsiveContainer>
        </div>
      </div>
    </div>
  );
};

export default Chart;
