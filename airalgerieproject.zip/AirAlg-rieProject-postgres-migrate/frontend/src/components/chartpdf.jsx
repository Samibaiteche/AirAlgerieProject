import React from "react";
import {
    AreaChart,
    Area,
    XAxis,
    YAxis,
    Tooltip,
    ResponsiveContainer,
    CartesianGrid, 
} from "recharts";

const Chartpdf = ({ chartData }) => {
    const formatYAxis = (tick) => {
        return `${(tick / 1000000).toFixed(2)}M`;
    };

    return (
        <div style={{ width: "100%" }}>
            {/* First Chart */}
            <div className="ml-8 mr-8 mt-2">
                <div className="flex flex-col items-start w-full">
                    <h3 className="font-poppins font-semibold mb-1 whitespace-nowrap">
                        Salaire brut
                    </h3>
                    <ResponsiveContainer
                        width="100%"
                        height={window.innerWidth < 768 ? 100 : 175}
                        className="bg-white py-1"
                    >
                        <AreaChart
                            data={chartData}
                            syncId="chartSync"
                            margin={{ top: 10, right: 10, left: 10, bottom: 0 }}
                        >
                            <XAxis dataKey="name" />
                            <YAxis tickFormatter={formatYAxis} />
                            <Tooltip />
                            <CartesianGrid strokeDasharray="3 3" /> {/* Dotted grid lines */}
                            <Area
                                type="monotone"
                                dataKey="sb"
                                stroke="#00CED1"
                                fill="#00CED155"
                            />
                        </AreaChart>
                    </ResponsiveContainer>
                </div>
            </div>
            {/* Second Chart */}
            <div className="ml-8 mr-8 mt-2">
                <div className="flex flex-col items-start w-full">
                    <h3 className="font-poppins font-semibold mb-1 whitespace-nowrap">
                        Charges patronales
                    </h3>
                    <ResponsiveContainer
                        width="100%"
                        height={window.innerWidth < 768 ? 100 : 175}
                        className="bg-white py-1"
                    >
                        <AreaChart
                            data={chartData}
                            syncId="chartSync"
                            margin={{ top: 10, right: 10, left: 10, bottom: 0 }}
                        >
                            <XAxis dataKey="name" />
                            <YAxis tickFormatter={formatYAxis} />
                            <Tooltip />
                            <CartesianGrid strokeDasharray="3 3" /> {/* Dotted grid lines */}
                            <Area
                                type="monotone"
                                dataKey="cp"
                                stroke="#B4EEB4"
                                fill="#B4EEB477"
                            />
                        </AreaChart>
                    </ResponsiveContainer>
                </div>
            </div>
            {/* Third Chart */}
            <div className="ml-8 mr-8 mt-2">
                <div className="flex flex-col items-start w-full">
                    <h3 className="font-poppins font-semibold mb-1 whitespace-nowrap">
                        Contributions sociales
                    </h3>
                    <ResponsiveContainer
                        width="100%"
                        height={window.innerWidth < 768 ? 100 : 175}
                        className="bg-white py-1"
                    >
                        <AreaChart
                            data={chartData}
                            syncId="chartSync"
                            margin={{ top: 10, right: 10, left: 10, bottom: 0 }}
                        >
                            <XAxis dataKey="name" />
                            <YAxis tickFormatter={formatYAxis} />
                            <Tooltip />
                            <CartesianGrid strokeDasharray="3 3" /> {/* Dotted grid lines */}
                            <Area
                                type="monotone"
                                dataKey="cs"
                                stroke="#FF6666"
                                fill="#FF666655"
                            />
                        </AreaChart>
                    </ResponsiveContainer>
                </div>
            </div>
            {/* Fourth Chart */}
            <div className="ml-8 mr-8 mt-2">
                <div className="flex flex-col items-start w-full">
                    <h3 className="font-poppins font-semibold mb-1 whitespace-nowrap">
                        Salaire total
                    </h3>
                    <ResponsiveContainer
                        width="100%"
                        height={window.innerWidth < 768 ? 100 : 175}
                        className="bg-white py-1"
                    >
                        <AreaChart
                            data={chartData}
                            syncId="chartSync"
                            margin={{ top: 10, right: 10, left: 10, bottom: 0 }}
                        >
                            <XAxis dataKey="name" />
                            <YAxis tickFormatter={formatYAxis} />
                            <Tooltip />
                            <CartesianGrid strokeDasharray="3 3" /> {/* Dotted grid lines */}
                            <Area
                                type="monotone"
                                dataKey="st"
                                stroke="#660066"
                                fill="#66006655"
                            />
                        </AreaChart>
                    </ResponsiveContainer>
                </div>
            </div>
        </div>
    );
};

export default Chartpdf;
