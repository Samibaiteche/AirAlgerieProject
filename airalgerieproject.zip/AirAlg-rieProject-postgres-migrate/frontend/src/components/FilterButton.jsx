import React from 'react';
import filter from '../../public/images/filter.png';

const FilterButton = ({ onClick }) => {
    return (
        <div onClick={onClick} className='flex hover:scale-105 flex-row bg-gradient-to-r from-[#f21414] to-[#f97777] text-white font-medium md:font-semibold font-poppins md:py-2 py-1 md:px-6 px-4 rounded-lg shadow-md hover:shadow-lg transition-shadow duration-300 cursor-pointer'>
            <button className="" >
                Filtre
            </button>
            <img src={filter} alt="filter" className="w-5 h-5 ml-4 mr-1 md:w-6 md:h-6 md:ml-6" />
        </div>
    );
};

export default FilterButton;
