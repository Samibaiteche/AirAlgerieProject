import React from 'react';

const GradientButton = ({ handleClick }) => {
    return (
        <button className="bg-gradient-to-r hover:scale-105 text-sm md:text-lg from-[#f21414] to-[#f97777] text-white font-medium md:font-semibold font-poppins py-1 md:py-2 px-4 md:px-6 md:rounded-lg rounded-md shadow-md hover:shadow-lg transition-shadow duration-300" onClick={handleClick}>
            Connexion
        </button>
    );
};

export default GradientButton;